const CACHE = 'potager-pro-v1';
const ASSETS = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS.filter(a => !a.endsWith('.png') || false))));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  // Météo et géo : toujours réseau, jamais cache
  if (e.request.url.includes('open-meteo.com') ||
      e.request.url.includes('geocoding-api') ||
      e.request.url.includes('nominatim')) {
    e.respondWith(fetch(e.request).catch(() => new Response('{}', {headers:{'Content-Type':'application/json'}})));
    return;
  }
  // Reste : cache first
  e.respondWith(caches.match(e.request).then(cached => cached || fetch(e.request)));
});
